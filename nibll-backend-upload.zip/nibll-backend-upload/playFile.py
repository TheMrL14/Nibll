import urllib
import urllib2
import subprocess
import time
from flask import Flask, url_for


app = Flask(__name__)
 
@app.route('/')
def api_root():
	return '<a href="http://nibll.local:5000/play/plop.mp3">Go to this link to play an example sound.</a> <br> <a href="http://nibll.local:5001/send?protocol=kaku_switch&id=27672578&unit=0&off=1"> turn off switch</a><br><a href="http://nibll.local:5001/send?protocol=kaku_switch&id=27672578&unit=0&on=1"> turn on switch</a>'


@app.route('/play/<filename>')
def api_play(filename):
    print filename
    file = filename
    p = subprocess.Popen(['mpg123', '/home/pi/' + file])
    return "play", 201, {'Access-Control-Allow-Origin': '*'} 
    
if __name__ == '__main__':
    app.run(host='nibll.local',debug = True)
